<?php

namespace App\Controller;

use App\Entity\Film;
use App\Entity\ListeDeFilm;
use phpDocumentor\Reflection\Types\Null_;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Annotation\Route;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\ParamConverter;
use Symfony\Component\Serializer\Encoder\JsonEncoder;
use Symfony\Component\Serializer\Normalizer\ObjectNormalizer;
use Symfony\Component\Serializer\Serializer;


/**
 * @Route("/api", name="api_")
 */
class ApiController extends AbstractController
{
    /**
     * recupere tous les films
     * @Route("/films/getAll", name="allMovie", methods={"GET"})
     */
    public function getAllFilm()
    {
        // On récupère tous les films
        $repo = $this->getDoctrine()->getRepository(Film::class);
        $films = $repo->findAll();

        // On utilise un encodeur JSON
        $encoders = [new JsonEncoder()];

        // On instancie le "normalizers" pour convertir la collection en tableau
        $normalizers = [new ObjectNormalizer()];

        // On fait la conversion en JSON
        // On instancie le "serializer"

        $serializer = new Serializer($normalizers, $encoders);

        //On convertit en JSON

        $jsonContent = $serializer->serialize($films, 'json', [
            'circular_reference_handler' => function($object){
                return $object->getId();
        }
        ]);

        $response = new Response($jsonContent);

        // On ajoute l'entete HTTP
        $response->headers->set('Content-Type', 'application/json');

        //On envoie la reponse
        return $response;

    }


    /**
     * recupere un seul film grace a son id
     * @Route("/film/getOne/{id}", name="oneMovie", methods={"GET"})
     */
        public function getOneFilm(Film $film)
        {
            // On utilise un encodeur JSON
            $encoders = [new JsonEncoder()];

            // On instancie le "normalizers" pour convertir la collection en tableau
            $normalizers = [new ObjectNormalizer()];

            // On fait la conversion en JSON
            // On instancie le "serializer"

            $serializer = new Serializer($normalizers, $encoders);

            //On convertit en JSON

            $jsonContent = $serializer->serialize($film, 'json', [
                'circular_reference_handler' => function($object){
                    return $object->getId();
                }
            ]);

            $response = new Response($jsonContent);

            // On ajoute l'entete HTTP
            $response->headers->set('Content-Type', 'application/json');

            //On envoie la reponse
            return $response;


        }


    /**
     * recupere un film grace a son nom
     * @Route("/film/getName/{title}", name="nameMovie", methods={"GET"})
     */
    public function getNameFilm(Film $film)
    {
        // On utilise un encodeur JSON
        $encoders = [new JsonEncoder()];

        // On instancie le "normalizers" pour convertir la collection en tableau
        $normalizers = [new ObjectNormalizer()];

        // On fait la conversion en JSON
        // On instancie le "serializer"

        $serializer = new Serializer($normalizers, $encoders);

        //On convertit en JSON

        $jsonContent = $serializer->serialize($film, 'json', [
            'circular_reference_handler' => function($object){
                return $object->getTitle();
            }
        ]);

        $response = new Response($jsonContent);

        // On ajoute l'entete HTTP
        $response->headers->set('Content-Type', 'application/json');

        //On envoie la reponse
        return $response;
    }


    /**
    * Ajout d'un film
    * @Route("/film/ajout"), name="ajout", methods={"POST"})
    */
    public function addFilm(Request $request)
    {
        // On verifie si on a une requete XMLHttpRequest (Je l'ai commenter pour tester avec l'API REST, a decommenter si vous utiliser des donnees JS)

        //        if($request->isXmlHttpRequest()) {
        //On verifie les donnees apres les avoir decodees

        $donnees = json_decode($request->getContent());

        //On instancie un nouvel article
        $film = new Film();

        //On "hydrate" nos donnees
        $film->setTitle($donnees->titre);
        $film->setYear($donnees->annee);
        $film->setSynopsis($donnees->synopsis);
        $film->setOriginalTitle($donnees->titreOriginal);
        $film->setOriginalCountry($donnees->paysOrigine);
        $film->setRealisator($donnees->realisateur);
        $film->setEvaluation($donnees->evaluation);
        if ($donnees->evaluation > 5 || $donnees->evaluation < 0) {
            return new Response('Erreur mauvaise note Evaluation', 500);
        }
//            On sauvegarde en base de donnees
        $em = $this->getDoctrine()->getManager();
        $em->persist($film);
        $em->flush();

        //On retourne la confirmation (Ajout du code 201 pour l'API REST)
        return new Response('Ajouter', 201);
        //a decommenter si vous utiliser des donnes JS
//        }
//        return new Response('Erreur',404);

    }


    /**
     * Modifie un film
     * @Route("/film/edit/{id}"), name="update", methods={"PUT"})
     */
    public function editFilm(?Film $film, Request $request)
    {

        // On verifie si on a une requete XMLHttpRequest (Je l'ai commenter pour tester avec l'API REST, a decommenter si vous utiliser des donnees JS)

//        if($request->isXmlHttpRequest()) {
        //On verifie les donnees apres les avoir decodees

        $donnees = json_decode($request->getContent());
        $code = 200;

        //Si on n'a pas de film a editer
        if (!$film) {
            // On instancie un nouveau film
            $film = new Film();

            //on met le code 201
            $code = 201;
        }
        //On "hydrate" nos donnees
        $film->setTitle($donnees->titre);
        $film->setYear($donnees->annee);
        $film->setSynopsis($donnees->synopsis);
        $film->setOriginalTitle($donnees->titreOriginal);
        $film->setOriginalCountry($donnees->paysOrigine);
        $film->setRealisator($donnees->realisateur);
        $film->setEvaluation($donnees->evaluation);

      if ($donnees->evaluation > 5 || $donnees->evaluation < 0) {
            return new Response('Erreur mauvaise note Evaluation', 500);
        }
//            On sauvegarde en base de donnees
        $em = $this->getDoctrine()->getManager();
        $em->persist($film);
        $em->flush();

        //On retourne la confirmation (Ajout du code 201 pour l'API REST)
        return new Response('Editer', $code);


        //a decommenter si vous utiliser des donnes JS
//        }
//        return new Response('Erreur',404);

    }


    /**
     * Supprime le Film
     * @Route("/film/supprimer/{id}", name="supprimer", methods={"DELETE"})
     */
    public function deleteFilm(Film $film){
        $em = $this->getDoctrine()->getManager();
        $em->remove($film);
        $em->flush();
        return new Response('Supprimer');
    }





    /**
     * Ajout d'une liste de film
     * @Route("/list/ajout/{film_id}"), name="listAjout", methods={"POST"})
     * @ParamConverter("film", options={"mapping": {"film_id" : "id"}})
     */
    public function addList(Film $film, Request $request)
    {
        // On verifie si on a une requete XMLHttpRequest (Je l'ai commenter pour tester avec l'API REST, a decommenter si vous utiliser des donnees JS)

        //        if($request->isXmlHttpRequest()) {
        //On verifie les donnees apres les avoir decodees

        $donnees = json_decode($request->getContent());
//

        //On instancie un nouvel article
        $listFilm = new ListeDeFilm();


        //On "hydrate" nos donnees
        $listFilm->setNom($donnees->nom);
        $listFilm->addListOfFilm($film);
        $listFilm->setDescription($donnees->description);
//            On sauvegarde en base de donnees
        $em = $this->getDoctrine()->getManager();
        $em->persist($listFilm);
        $em->flush();

        //On retourne la confirmation (Ajout du code 201 pour l'API REST)
        return new Response('Ajouter', 201);
        //a decommenter si vous utiliser des donnes JS
//        }
//        return new Response('Erreur',404);

    }


    /**
     * recupere un seul liste de film grace a son id
     * @Route("/list/getOne/{id}", name="onelist", methods={"GET"})
     */
    public function getOneList(ListeDeFilm $list)
    {
        // On utilise un encodeur JSON
        $encoders = [new JsonEncoder()];

        // On instancie le "normalizers" pour convertir la collection en tableau
        $normalizers = [new ObjectNormalizer()];

        // On fait la conversion en JSON
        // On instancie le "serializer"

        $serializer = new Serializer($normalizers, $encoders);

        //On convertit en JSON

        $jsonContent = $serializer->serialize($list, 'json', [
            'circular_reference_handler' => function($object){
                return $object->getId();
            }
        ]);

        $response = new Response($jsonContent);

        // On ajoute l'entete HTTP
        $response->headers->set('Content-Type', 'application/json');

        //On envoie la reponse
        return $response;


    }


    /**
     * Modifie une liste de film
     * @Route("/list/edit/{id}/{film_id}"), name="update", methods={"PUT"})
     * @ParamConverter("film", options={"mapping": {"film_id" : "id"}})
     */
    public function editList(?ListeDeFilm $listFilm, ?Film $film, Request $request)
    {

        // On verifie si on a une requete XMLHttpRequest (Je l'ai commenter pour tester avec l'API REST, a decommenter si vous utiliser des donnees JS)

//        if($request->isXmlHttpRequest()) {
        //On verifie les donnees apres les avoir decodees

        $donnees = json_decode($request->getContent());
        $code = 200;

        //Si on n'a pas de film a editer
        if (!$listFilm) {
            // On instancie un nouveau film
            $listFilm = new ListeDeFilm();

            //on met le code 201
            $code = 201;
        }


        //On "hydrate" nos donnees
        $listFilm->setNom($donnees->nom);
        $listFilm->addListOfFilm($film);
        $listFilm->setDescription($donnees->description);
//            On sauvegarde en base de donnees
        $em = $this->getDoctrine()->getManager();
        $em->persist($listFilm);
        $em->flush();


        //On retourne la confirmation (Ajout du code 201 pour l'API REST)
        return new Response('Editer', $code);


        //a decommenter si vous utiliser des donnes JS
//        }
//        return new Response('Erreur',404);

    }


    /**
     * Ajouter un film dans une liste de film
     * @Route("/list/addMovie/{id}/{film_id}"), name="addMovieInList", methods={"PUT"})
     * @ParamConverter("film", options={"mapping": {"film_id" : "id"}})
     */
    public function addMovieInList(ListeDeFilm $listFilm, Film $film)
    {

        $listFilm->addListOfFilm($film);
//            On sauvegarde en base de donnees
        $em = $this->getDoctrine()->getManager();
        $em->persist($listFilm);
        $em->flush();


        //On retourne la confirmation (Ajout du code 201 pour l'API REST)
        return new Response('Ajouter', 200);


        //a decommenter si vous utiliser des donnes JS
//        }
//        return new Response('Erreur',404);

    }


    /**
     * Supprimer un film dans une liste de film
     * @Route("/list/deleteMovie/{id}/{film_id}"), name="deleteMovieInList", methods={"PUT"})
     * @ParamConverter("film", options={"mapping": {"film_id" : "id"}})
     */
    public function deleteMovieInList(ListeDeFilm $listFilm, Film $film)
    {

        $listFilm->removeListOfFilm($film);
    //            On sauvegarde en base de donnees
        $em = $this->getDoctrine()->getManager();
        $em->persist($listFilm);
        $em->flush();


        //On retourne la confirmation (Ajout du code 201 pour l'API REST)
        return new Response('Ajouter', 200);


        //a decommenter si vous utiliser des donnes JS
    //        }
    //        return new Response('Erreur',404);

    }


    /**
     * Supprime la liste de Film
     * @Route("/list/supprimer/{id}", name="supprimerListe", methods={"DELETE"})
     */
    public function deleteListeFilm(ListeDeFilm $listeFilm){
        $em = $this->getDoctrine()->getManager();
        $em->remove($listeFilm);
        $em->flush();
        return new Response('Supprimer');
    }

}