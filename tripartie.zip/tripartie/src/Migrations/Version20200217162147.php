<?php

declare(strict_types=1);

namespace DoctrineMigrations;

use Doctrine\DBAL\Schema\Schema;
use Doctrine\Migrations\AbstractMigration;

/**
 * Auto-generated Migration: Please modify to your needs!
 */
final class Version20200217162147 extends AbstractMigration
{
    public function getDescription() : string
    {
        return '';
    }

    public function up(Schema $schema) : void
    {
        // this up() migration is auto-generated, please modify it to your needs
        $this->abortIf($this->connection->getDatabasePlatform()->getName() !== 'mysql', 'Migration can only be executed safely on \'mysql\'.');

        $this->addSql('CREATE TABLE liste_de_film (id INT AUTO_INCREMENT NOT NULL, nom VARCHAR(255) NOT NULL, description LONGTEXT DEFAULT NULL, PRIMARY KEY(id)) DEFAULT CHARACTER SET utf8mb4 COLLATE `utf8mb4_unicode_ci` ENGINE = InnoDB');
        $this->addSql('CREATE TABLE liste_de_film_film (liste_de_film_id INT NOT NULL, film_id INT NOT NULL, INDEX IDX_915AE6A7788DFA96 (liste_de_film_id), INDEX IDX_915AE6A7567F5183 (film_id), PRIMARY KEY(liste_de_film_id, film_id)) DEFAULT CHARACTER SET utf8mb4 COLLATE `utf8mb4_unicode_ci` ENGINE = InnoDB');
        $this->addSql('ALTER TABLE liste_de_film_film ADD CONSTRAINT FK_915AE6A7788DFA96 FOREIGN KEY (liste_de_film_id) REFERENCES liste_de_film (id) ON DELETE CASCADE');
        $this->addSql('ALTER TABLE liste_de_film_film ADD CONSTRAINT FK_915AE6A7567F5183 FOREIGN KEY (film_id) REFERENCES film (id) ON DELETE CASCADE');
    }

    public function down(Schema $schema) : void
    {
        // this down() migration is auto-generated, please modify it to your needs
        $this->abortIf($this->connection->getDatabasePlatform()->getName() !== 'mysql', 'Migration can only be executed safely on \'mysql\'.');

        $this->addSql('ALTER TABLE liste_de_film_film DROP FOREIGN KEY FK_915AE6A7788DFA96');
        $this->addSql('DROP TABLE liste_de_film');
        $this->addSql('DROP TABLE liste_de_film_film');
    }
}
