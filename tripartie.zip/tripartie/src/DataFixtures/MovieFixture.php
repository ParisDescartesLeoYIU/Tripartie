<?php

namespace App\DataFixtures;

use Doctrine\Bundle\FixturesBundle\Fixture;
use Doctrine\Common\Persistence\ObjectManager;
use App\Entity\Film;

class MovieFixture extends Fixture
{
    public function load(ObjectManager $manager)
    {

        for ($i=1; $i <=10;$i++){
            $film = new Film();
            $film->setTitle("Titre du film numero $i")
                ->setYear(2010+$i)
                 ->setSynopsis("<p>Synopsis du film numero $i</p>")
                ->setOriginalTitle("Titre originale du film numero $i")
                ->setEvaluation($i);
            if ($i%2==0){
                $film->setOriginalCountry("France")
                    ->setRealisator("Realisateur du film numero $i");
            }

            $manager->persist($film);
        }
        
        $manager->flush();
    }
}
