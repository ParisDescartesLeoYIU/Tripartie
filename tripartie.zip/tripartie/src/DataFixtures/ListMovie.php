<?php
//
//namespace App\DataFixtures;
//
//use App\Entity\ListeDeFilm;
//use Doctrine\Bundle\FixturesBundle\Fixture;
//use Doctrine\Common\Persistence\ObjectManager;
//
//class ListMovie extends Fixture
//{
//    public function load(ObjectManager $manager)
//    {
//
//        for ($i=1; $i <=4;$i++){
//            $listFilm = new ListeDeFilm();
//            $listFilm->setNom("Liste numero $i");
//
//            if ($i%2==0){
//                $listFilm->setDescription("<p>Contenu de la list numero $i</p>");
//            }
//
//            $manager->persist($listFilm);
//        }
//
//        $manager->flush();
//    }
//}
